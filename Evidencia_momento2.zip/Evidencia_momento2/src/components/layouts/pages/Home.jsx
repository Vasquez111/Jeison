import React from 'react'
import Lateral from '../../helpers/Lateral'

const Home = () => {
  return (
    <div> <Lateral/>

    <p className='Texto'>Panel de control</p>


     </div>
  )
  
}



export default Home