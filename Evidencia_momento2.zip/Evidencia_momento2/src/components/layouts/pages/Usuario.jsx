import React from 'react'
import Lateral from '../../helpers/Lateral'
import './Usuario.css'

const Usuario = () => {
  return (
    <div><Lateral/>
    <img className='luffy' src="https://www.bvb.de/var/ezdemo_site/storage/images/media/startseite/werbezeile/shopzeile_merchandising/2237119-170-eng-GB/Shopzeile.png" alt="" />
    <div className='Contenido'>
        <p>Empresa: Cesde</p>
        <p>Contratacion: 10/02/2019</p>
        <p>Salario: 20.000.000 </p>
        <p>Nombre: Jaime Zapata Valencia</p>
        <p>Correo: correo@correo.com</p>
    </div>
    
    
    </div>
  )
}
export default Usuario