import { Link } from "react-router-dom";
import "./Lateral.css"

const Lateral = () => {
    return (
      <section className="laterall">
        
        <img className="imagen" src="https://cdn.icon-icons.com/icons2/1018/PNG/256/Borussia_Dortmund_icon-icons.com_75869.png" alt="" />
        <a>
            <Link to="/home">Menú Home</Link>
        </a>
        <a>
            <Link to="/user">Usuario</Link>
        </a>
        <a>
            <Link to="/">Cerrar Sesión</Link>
        </a>


      </section>
    );
  };

  

export default Lateral